#!/bin/sh
git pull